.. pylinkwrapper documentation master file, created by
   sphinx-quickstart on Tue Oct 20 11:24:52 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Pylinkwrapper's Documentation!
=========================================

Contents:

.. toctree::
   :maxdepth: 2

   installation
   connector
   sample

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

