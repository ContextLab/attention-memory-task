Connector Class
=========================================
This class provides methods for interacting with the Eyelink from psychopy.

.. automodule:: connector
.. autoclass:: Connect
    :members:
