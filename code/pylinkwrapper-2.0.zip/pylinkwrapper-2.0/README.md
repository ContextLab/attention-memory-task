# Pylink Wrapper
Wrapper for using pylink in psychopy

## Documentation
[![Documentation Status](https://readthedocs.org/projects/pylinkwrapper/badge/?version=latest)](http://pylinkwrapper.readthedocs.org/en/latest/?badge=latest)

http://pylinkwrapper.readthedocs.org/

## Example
An very simple experiment that shows how to use the above functions is provided in `eyetest.py`.
